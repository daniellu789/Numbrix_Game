how to execute my code

1. Under gcl to execute (compile-file "Numbrix.lisp"), after compiling, there will be a new file named "Numbrix.o"

2. Under gcl to execute (load "Numbrix.o")

3. After loading the program, it will have automatically execute (numbrix), then you begin the game

4. If want to execute the game again after you end the end, just execute (numbrix)

*note: the borad 1~17 is from "Tournament Data F13.pdf", and 18~24 is from " Additional Boards F13.pdf"
